package Database;

public class ConnectionData {
    public static final String DRIVER = "com.mysql.jdbc.Driver";
    public static final String DB = "catalog";
    public static final String URL = "jdbc:mysql://localhost:3306/" + DB;
    public static final String USER = "root";
    public static final String PASSWORD = "Noname52484sl";
}