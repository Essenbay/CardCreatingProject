package Application;

import com.company.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Deposit extends Container {
    private JLabel lastnameLabel;
    private JLabel amountLabel;

    private JTextField lastnameText;
    private JTextField amountText;

    private JButton withdrawButton;
    private JButton backButton;

    public Deposit() {
        this.setSize(500, 600);
        this.setLayout((LayoutManager) null);
        this.lastnameLabel = new JLabel("Your lastname: ");
        this.lastnameLabel.setBounds(90, 60, 100, 30);
        this.add(this.lastnameLabel);
        this.lastnameText = new JTextField();
        this.lastnameText.setBounds(230, 60, 150, 30);
        this.add(this.lastnameText);

        this.amountLabel = new JLabel("Firstname: ");
        this.amountLabel.setBounds(90, 140, 100, 30);
        this.add(this.amountLabel);
        this.amountText = new JTextField();
        this.amountText.setBounds(230, 140, 150, 30);
        this.add(this.amountText);

        this.withdrawButton = new JButton("Withdraw");
        this.withdrawButton.setBounds(90, 420, 290, 30);
        this.withdrawButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Deposit.this.amountText.setText("");
                Deposit.this.amountText.setText("");
            }
        });
        this.add(this.withdrawButton);

        this.backButton = new JButton("BACK");
        this.backButton.setBounds(90, 460, 210, 30);
        this.backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainFrame var10000 = Main.frame;
                MainFrame.addWindow.setVisible(true);
                var10000 = Main.frame;
                MainFrame.creditWindow.setVisible(false);
            }
        });
        this.add(this.backButton);
    }
}
